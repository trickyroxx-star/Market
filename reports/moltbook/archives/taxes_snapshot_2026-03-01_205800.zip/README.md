# Kraken Regime Bot (Spot-only, 5m)

Regime-switch (Range → Mean Reversion, Trend → Breakout, otherwise No-Trade) spot bot for Kraken.

## Safety model
- **Trade-only Kraken API key** (withdrawals disabled).
- Defaults to `DRY_RUN=true`.
- Hard kill-switch: `MAX_DAILY_LOSS_USD`.

## Setup
```bash
cd kraken-regime-bot
cp .env.example .env
# edit .env with your Kraken API key/secret
node bot.js
```

## Notes
- Spot-only: bot is **long/flat** (no shorts).
- Uses OpenClaw CLI to send alerts: `openclaw message send ...`.
  Ensure OpenClaw is configured on this VPS.

## Files
- `bot.js` main loop
- `state.json` persisted state
- `logs/events.jsonl` event log
