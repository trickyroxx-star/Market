#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# naive stop: kill node bot.js processes in this folder
pids=$(pgrep -f "node bot.js" || true)
if [ -z "$pids" ]; then
  echo "No bot.js process found"
  exit 0
fi

echo "$pids" | xargs kill
echo "Stopped: $pids"
