import 'dotenv/config';
import ccxt from 'ccxt';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ADX, ATR, RSI, BollingerBands, EMA } from 'technicalindicators';
import pino from 'pino';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const LOG_DIR = path.join(__dirname, 'logs');
const EVENTS_PATH = path.join(LOG_DIR, 'events.jsonl');
const STATE_PATH = path.join(__dirname, 'state.json');

fs.mkdirSync(LOG_DIR, { recursive: true });

const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  transport: {
    target: 'pino-pretty',
    options: { colorize: true, translateTime: 'SYS:standard' },
  },
});

function envBool(name, fallback = false) {
  const v = process.env[name];
  if (v === undefined) return fallback;
  return ['1', 'true', 'yes', 'y', 'on'].includes(String(v).toLowerCase());
}

function nowMs() {
  return Date.now();
}

function readState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
  } catch {
    return {
      day: new Date().toISOString().slice(0, 10),
      realizedPnlUsd: 0,
      consecutiveLosses: 0,
      cooldownUntilMs: 0,
      position: null, // {symbol, side:'long', amount, entryPrice, entryTimeMs, regime}
    };
  }
}

function writeState(state) {
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
}

function appendEvent(evt) {
  fs.appendFileSync(EVENTS_PATH, JSON.stringify(evt) + '\n');
}

async function sendAlert(kind, text) {
  const enabled = envBool('ALERTS_ENABLED', true);
  if (!enabled) return;

  // Only allow ENTRY/EXIT alerts for now.
  if (!['ENTER', 'EXIT'].includes(kind)) return;

  const channel = process.env.ALERTS_CHANNEL || 'telegram';
  const target = process.env.ALERTS_TARGET;
  if (!target) return;

  // Force alerts to go out via the Tax bot account.
  const account = process.env.ALERTS_ACCOUNT || 'taxes';

  // Use OpenClaw CLI so we don't embed bot tokens.
  const { execFile } = await import('node:child_process');
  return new Promise((resolve) => {
    const child = execFile(
      'openclaw',
      ['message', 'send', '--channel', channel, '--account', account, '--target', target, '--message', text],
      { timeout: 10_000 },
      (error, stdout, stderr) => {
        // Log delivery result into events.jsonl for auditing
        try {
          const evt = {
            t: new Date().toISOString(),
            type: 'ALERT_SEND',
            kind,
            channel,
            target,
            account,
            message_preview: String(text).slice(0, 200),
            error: error ? String(error) : null,
            stdout: stdout ? String(stdout).slice(0, 500) : null,
            stderr: stderr ? String(stderr).slice(0, 500) : null,
          };
          appendEvent(evt);
        } catch (e) {
          // nothing — don't let alert logging crash the bot
        }
        resolve({ error, stdout, stderr });
      }
    );
    // in case of immediate spawn errors
    child.on('error', (e) => {
      try { appendEvent({ t: new Date().toISOString(), type: 'ALERT_SEND', kind, error: String(e) }); } catch (_) {}
    });
  });
}

function bpsFromPrices(bid, ask) {
  if (!bid || !ask) return Infinity;
  const mid = (bid + ask) / 2;
  return ((ask - bid) / mid) * 10_000;
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function clamp(n, lo, hi) {
  return Math.max(lo, Math.min(hi, n));
}

function roundTo(n, decimals = 6) {
  const p = 10 ** decimals;
  return Math.round(n * p) / p;
}

const config = {
  dryRun: envBool('DRY_RUN', true),
  symbols: (process.env.SYMBOLS || 'SOL/USDC,BTC/USDC,ETH/USDC').split(',').map(s => s.trim()).filter(Boolean),
  timeframe: process.env.TIMEFRAME || '5m',
  maxDailyLossUsd: Number(process.env.MAX_DAILY_LOSS_USD || 25),
  maxHoldMinutes: Number(process.env.MAX_HOLD_MINUTES || 240),
  maxConsecutiveLosses: Number(process.env.MAX_CONSECUTIVE_LOSSES || 3),
  cooldownMinutes: Number(process.env.COOLDOWN_MINUTES || 60),
  maxPositionFraction: Number(process.env.MAX_POSITION_FRACTION || 0.30),
  minUsdcToTrade: Number(process.env.MIN_USDC_TO_TRADE || 15),
  adxRangeMax: Number(process.env.ADX_RANGE_MAX || 18),
  adxTrendMin: Number(process.env.ADX_TREND_MIN || 25),
  maxSpreadBps: Number(process.env.MAX_SPREAD_BPS || 20),
};

if (!process.env.KRAKEN_API_KEY || !process.env.KRAKEN_API_SECRET) {
  logger.warn('Missing KRAKEN_API_KEY/KRAKEN_API_SECRET. Bot will run but cannot trade.');
}

const exchange = new ccxt.kraken({
  apiKey: process.env.KRAKEN_API_KEY,
  secret: process.env.KRAKEN_API_SECRET,
  enableRateLimit: true,
});
// Increase HTTP timeout to reduce transient timeouts (ms)
exchange.timeout = 20000;

async function fetchIndicators(symbol) {
  // Pull last ~200 candles for stable indicators.
  const ohlcv = await exchange.fetchOHLCV(symbol, config.timeframe, undefined, 200);
  const opens = ohlcv.map(x => x[1]);
  const highs = ohlcv.map(x => x[2]);
  const lows = ohlcv.map(x => x[3]);
  const closes = ohlcv.map(x => x[4]);

  const adxArr = ADX.calculate({ high: highs, low: lows, close: closes, period: 14 });
  const atrArr = ATR.calculate({ high: highs, low: lows, close: closes, period: 14 });
  const rsiArr = RSI.calculate({ values: closes, period: 14 });
  const bbArr = BollingerBands.calculate({ values: closes, period: 20, stdDev: 2 });
  const emaArr = EMA.calculate({ values: closes, period: 20 });

  const last = {
    ts: ohlcv[ohlcv.length - 1][0],
    open: opens.at(-1),
    high: highs.at(-1),
    low: lows.at(-1),
    close: closes.at(-1),
    adx: adxArr.at(-1)?.adx,
    atr: atrArr.at(-1),
    rsi: rsiArr.at(-1),
    bb: bbArr.at(-1),
    ema: emaArr.at(-1),
    hh20: Math.max(...highs.slice(-20)),
    ll20: Math.min(...lows.slice(-20)),
    hh10: Math.max(...highs.slice(-10)),
    ll10: Math.min(...lows.slice(-10)),
  };

  return last;
}

function classifyRegime(ind) {
  if (!Number.isFinite(ind.adx)) return 'NO_TRADE';
  if (ind.adx <= config.adxRangeMax) return 'RANGE';
  if (ind.adx >= config.adxTrendMin) return 'TREND';
  return 'NO_TRADE';
}

async function fetchSpreadOk(symbol) {
  // Low-risk: retry fetchOrderBook once on transient failure
  const maxAttempts = 2;
  let attempt = 0;
  let lastErr = null;
  while (attempt < maxAttempts) {
    try {
      const ob = await exchange.fetchOrderBook(symbol, 5);
      const bid = ob.bids?.[0]?.[0];
      const ask = ob.asks?.[0]?.[0];
      const spreadBps = bpsFromPrices(bid, ask);
      return { ok: spreadBps <= config.maxSpreadBps, spreadBps, bid, ask };
    } catch (err) {
      lastErr = err;
      attempt += 1;
      // short backoff
      await new Promise((res) => setTimeout(res, 500 * attempt));
    }
  }
  // logged error will be captured by caller via thrown exception or we return not-ok
  appendEvent({ t: new Date().toISOString(), type: 'ERROR', error: String(lastErr) });
  return { ok: false, spreadBps: Infinity, bid: null, ask: null };
}

async function getUsdcFree() {
  const bal = await exchange.fetchBalance();
  // Kraken sometimes uses 'USDC' key; CCXT normalizes.
  return Number(bal.free?.USDC || 0);
}

async function getAssetFree(asset) {
  const bal = await exchange.fetchBalance();
  return Number(bal.free?.[asset] || 0);
}

async function placeMarketBuy(symbol, usdcAmount) {
  // For spot, we buy base with quote amount. CCXT expects amount in base.
  // We approximate by using last price and buying base amount; slippage handled by market.
  const ticker = await exchange.fetchTicker(symbol);
  const price = Number(ticker.last);
  const baseAmount = usdcAmount / price;
  if (config.dryRun) {
    return { dryRun: true, symbol, side: 'buy', baseAmount, estPrice: price };
  }
  return exchange.createMarketBuyOrder(symbol, baseAmount);
}

async function placeMarketSell(symbol, baseAmount) {
  if (config.dryRun) {
    return { dryRun: true, symbol, side: 'sell', baseAmount };
  }
  return exchange.createMarketSellOrder(symbol, baseAmount);
}

function shouldEnterMeanReversion(ind) {
  if (!ind.bb || !Number.isFinite(ind.rsi) || !Number.isFinite(ind.ema)) return false;
  // Buy oversold near/below lower band.
  return ind.close <= ind.bb.lower * 1.005 && ind.rsi <= 35;
}

function shouldEnterBreakout(ind) {
  if (!Number.isFinite(ind.hh10) || !Number.isFinite(ind.close)) return false;
  // Breakout above recent highs.
  return ind.close > ind.hh10 * 1.0001;
}

function shouldExitMeanReversion(ind, pos) {
  // Exit when mean reverts to EMA or RSI normalizes.
  if (!Number.isFinite(ind.ema) || !Number.isFinite(ind.rsi)) return false;
  return ind.close >= ind.ema || ind.rsi >= 50;
}

function shouldExitBreakout(ind, pos) {
  // Exit if price falls back below EMA (momentum failed).
  if (!Number.isFinite(ind.ema)) return false;
  return ind.close < ind.ema;
}

function pct(a, b) {
  return (b - a) / a;
}

async function mainLoop() {
  let state = readState();

  // Day rollover: reset realized PnL and loss counters.
  const today = todayStr();
  if (state.day !== today) {
    state.day = today;
    state.realizedPnlUsd = 0;
    state.consecutiveLosses = 0;
    state.cooldownUntilMs = 0;
    state.position = null;
    writeState(state);
    await sendAlert('INFO', `[BOT] New day: reset counters.`);
  }

  // Global kill-switch.
  if (state.realizedPnlUsd <= -Math.abs(config.maxDailyLossUsd)) {
    logger.warn({ realizedPnlUsd: state.realizedPnlUsd }, 'Daily loss limit hit. Bot disabled until tomorrow.');
    return;
  }

  if (state.cooldownUntilMs && nowMs() < state.cooldownUntilMs) {
    logger.info({ until: new Date(state.cooldownUntilMs).toISOString() }, 'Cooldown active.');
    return;
  }

  // Heartbeat so you can verify the bot is alive even when it does nothing.
  appendEvent({
    t: new Date().toISOString(),
    type: 'TICK',
    dryRun: config.dryRun,
    realizedPnlUsd: roundTo(state.realizedPnlUsd, 4),
    consecutiveLosses: state.consecutiveLosses,
    inCooldown: !!(state.cooldownUntilMs && nowMs() < state.cooldownUntilMs),
    hasPosition: !!state.position,
  });

  // Manage open position.
  if (state.position) {
    const pos = state.position;
    const ind = await fetchIndicators(pos.symbol);
    const regimeNow = classifyRegime(ind);

    const heldMinutes = (nowMs() - pos.entryTimeMs) / 60000;
    const exitByTime = heldMinutes >= config.maxHoldMinutes;

    let exitSignal = false;
    if (pos.regime === 'RANGE') exitSignal = shouldExitMeanReversion(ind, pos);
    if (pos.regime === 'TREND') exitSignal = shouldExitBreakout(ind, pos);

    // Use ATR-scaled stops to avoid tiny noise exits. Stop = entryPrice - k*ATR
    const ATR_MULTIPLIER_STOP = pos.regime === 'RANGE' ? 3.0 : 2.0; // tighter for trends
    const atrVal = ind.atr || 0;
    const stopPrice = pos.entryPrice - ATR_MULTIPLIER_STOP * atrVal;
    const move = pct(pos.entryPrice, ind.close);
    const exitByStop = ind.close <= stopPrice;

    const takeProfitPct = pos.regime === 'RANGE' ? 0.008 : 0.015;
    const exitByTp = move >= takeProfitPct;

    if (exitByTime || exitSignal || exitByStop || exitByTp || regimeNow === 'NO_TRADE') {
      const base = pos.symbol.split('/')[0];
      const baseFree = await getAssetFree(base);
      const sellAmount = Math.min(baseFree, pos.amount);

      const spread = await fetchSpreadOk(pos.symbol);
      if (!spread.ok) {
        logger.warn({ spreadBps: spread.spreadBps, symbol: pos.symbol }, 'Spread too wide to exit safely; skipping this tick.');
        return;
      }

      const res = await placeMarketSell(pos.symbol, sellAmount);
      const exitPrice = ind.close;
      const pnlUsd = (exitPrice - pos.entryPrice) * sellAmount;

      state.realizedPnlUsd += pnlUsd;
      if (pnlUsd < 0) state.consecutiveLosses += 1; else state.consecutiveLosses = 0;

      if (state.consecutiveLosses >= config.maxConsecutiveLosses) {
        state.cooldownUntilMs = nowMs() + config.cooldownMinutes * 60000;
      }

      appendEvent({
        t: new Date().toISOString(),
        type: 'EXIT',
        symbol: pos.symbol,
        regime: pos.regime,
        reason: exitByTime ? 'TIME' : exitByStop ? 'STOP' : exitByTp ? 'TP' : exitSignal ? 'SIGNAL' : 'REGIME_NO_TRADE',
        entryPrice: pos.entryPrice,
        exitPrice,
        amount: sellAmount,
        pnlUsd: roundTo(pnlUsd, 4),
        realizedPnlUsd: roundTo(state.realizedPnlUsd, 4),
        dryRun: config.dryRun,
        order: res,
      });

      await sendAlert('EXIT', `[BOT] EXIT ${pos.symbol} (${pos.regime}) @~${exitPrice.toFixed(4)} | PnL ${pnlUsd.toFixed(2)} USDC | day ${state.realizedPnlUsd.toFixed(2)}${config.dryRun ? ' [DRY_RUN]' : ''}`);

      state.position = null;
      writeState(state);
      return;
    }

    logger.info({ symbol: pos.symbol, heldMinutes: Math.round(heldMinutes), movePct: (move * 100).toFixed(2) }, 'Position held.');
    return;
  }

  // If no position: scan symbols for an entry.
  for (const symbol of config.symbols) {
    // REGIME visibility (debug): log what the bot sees
    const __indPeek = await fetchIndicators(symbol);
    const __regPeek = classifyRegime(__indPeek);
    const __spreadPeek = await fetchSpreadOk(symbol);
    appendEvent({t:new Date().toISOString(), type:"REGIME", symbol, regime:__regPeek, adx:__indPeek.adx, rsi:__indPeek.rsi, spreadBps:__spreadPeek.spreadBps, spreadOk:__spreadPeek.ok});

    const ind = await fetchIndicators(symbol);
    const regime = classifyRegime(ind);

    const spread = await fetchSpreadOk(symbol);
    if (!spread.ok) {
      appendEvent({ t: new Date().toISOString(), type: 'SKIP', symbol, reason: 'SPREAD', spreadBps: spread.spreadBps });
      continue;
    }

    if (regime === 'NO_TRADE') {
      continue;
    }

    let enter = false;
    if (regime === 'RANGE') enter = shouldEnterMeanReversion(ind);
    if (regime === 'TREND') enter = shouldEnterBreakout(ind);

    if (!enter) continue;

    // VOLATILITY FILTER: avoid entering overly noisy markets, but allow higher threshold for volatile tickers like SOL
    const atr = ind.atr || 0;
    const volPct = atr && ind.close ? (atr / ind.close) : 0;
    // per-symbol thresholds (SOL is allowed higher volatility)
    const symbolVolThresholds = {
      'SOL/USDC': 0.04, // 4%
      'BTC/USDC': 0.03,
      'ETH/USDC': 0.03,
    };
    const VOL_THRESHOLD = symbolVolThresholds[symbol] || 0.02; // default 2%
    if (volPct > VOL_THRESHOLD) {
      appendEvent({ t: new Date().toISOString(), type: 'SKIP', symbol, reason: 'VOLATILE', atr, volPct, threshold: VOL_THRESHOLD });
      continue;
    }

    const usdcFree = await getUsdcFree();
    if (usdcFree < config.minUsdcToTrade) {
      appendEvent({ t: new Date().toISOString(), type: 'SKIP', symbol, reason: 'NO_USDC', usdcFree });
      continue;
    }

    // Size: fraction of available USDC.
    const spend = clamp(usdcFree * config.maxPositionFraction, config.minUsdcToTrade, usdcFree);
    const res = await placeMarketBuy(symbol, spend);

    const entryPrice = ind.close;
    const baseAmountEst = spend / entryPrice;

    state.position = {
      symbol,
      side: 'long',
      amount: baseAmountEst,
      entryPrice,
      entryTimeMs: nowMs(),
      regime,
    };

    appendEvent({
      t: new Date().toISOString(),
      type: 'ENTER',
      symbol,
      regime,
      price: entryPrice,
      spendUsdc: roundTo(spend, 2),
      estAmount: roundTo(baseAmountEst, 6),
      dryRun: config.dryRun,
      order: res,
      indicators: {
        adx: ind.adx,
        rsi: ind.rsi,
        ema: ind.ema,
        bbLower: ind.bb?.lower,
        bbUpper: ind.bb?.upper,
      },
    });

    writeState(state);
    await sendAlert('ENTER', `[BOT] ENTER ${symbol} (${regime}) spend ~${spend.toFixed(2)} USDC @~${entryPrice.toFixed(4)}${config.dryRun ? ' [DRY_RUN]' : ''}`);
    break; // one position globally
  }
}

async function run() {
  await exchange.loadMarkets();
  logger.info({ dryRun: config.dryRun, symbols: config.symbols, timeframe: config.timeframe }, 'Bot starting');

  // Align to 5m-ish ticks: run every 60s but decisions are based on 5m candles.
  // Safer: frequent checks for exits/spread, but only one position.
  setInterval(() => {
    mainLoop().catch((err) => {
      logger.error({ err: String(err), stack: err?.stack }, 'mainLoop error');
      appendEvent({ t: new Date().toISOString(), type: 'ERROR', error: String(err) });
    });
  }, 60_000);

  // Kick once immediately.
  await mainLoop();
}

run().catch((err) => {
  logger.error({ err: String(err), stack: err?.stack }, 'fatal');
  process.exit(1);
});
