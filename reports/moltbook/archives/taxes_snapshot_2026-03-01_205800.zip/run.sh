#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -f .env ]; then
  echo "Missing .env. Run: cp .env.example .env && edit it"
  exit 1
fi

mkdir -p logs

# Run in background, write stdout/stderr to logs
nohup npm run start > logs/stdout.log 2> logs/stderr.log &

echo "Started. PID: $!"
