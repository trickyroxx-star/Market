from pathlib import Path

p = Path("bot.js")
s = p.read_text()

marker = "for (const symbol of config.symbols) {"
insert = marker + """
    // REGIME visibility (debug): log what the bot sees
    const __indPeek = await fetchIndicators(symbol);
    const __regPeek = classifyRegime(__indPeek);
    const __spreadPeek = await fetchSpreadOk(symbol);
    appendEvent({t:new Date().toISOString(), type:"REGIME", symbol, regime:__regPeek, adx:__indPeek.adx, rsi:__indPeek.rsi, spreadBps:__spreadPeek.spreadBps, spreadOk:__spreadPeek.ok});
"""

s2 = s.replace(marker, insert, 1)

if s2 == s:
    print("marker_not_found")
else:
    p.write_text(s2)
    print("patched")
